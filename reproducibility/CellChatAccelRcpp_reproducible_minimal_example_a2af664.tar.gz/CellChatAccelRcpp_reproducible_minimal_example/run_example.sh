#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
R_BIN="${R_BIN:-/home/dzf/miniforge3/envs/cellchat-acceleration/bin/R}"
R_SCRIPT="${R_SCRIPT:-/home/dzf/miniforge3/envs/cellchat-acceleration/bin/Rscript}"
GITHUB_REF="${GITHUB_REF:-a2af6647db29bf6d1b59a4f42ead6e848ed9ab8e}"
PRIVATE_LIB="${PRIVATE_LIB:-${ROOT}/r-library}"
RESULTS="${ROOT}/results"
SOURCE_TARBALL="${SOURCE_TARBALL:-${ROOT}/vendor/CellChatAccelRcpp_0.1.3.tar.gz}"
export R_MAKEVARS_USER="${R_MAKEVARS_USER:-${ROOT}/config/Makevars}"

mkdir -p "${PRIVATE_LIB}" "${RESULTS}"

if [[ "${SKIP_INSTALL:-0}" != "1" ]]; then
  "${R_SCRIPT}" "${ROOT}/scripts/install_github.R" \
    "${GITHUB_REF}" "${PRIVATE_LIB}" "${SOURCE_TARBALL}"
fi

export R_LIBS_USER="${PRIVATE_LIB}${R_LIBS_USER:+:${R_LIBS_USER}}"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1

"${R_SCRIPT}" "${ROOT}/scripts/check_install.R" "${GITHUB_REF}" \
  > "${RESULTS}/install_check.log"

/usr/bin/time -v -o "${RESULTS}/original.time.txt" \
  "${R_SCRIPT}" "${ROOT}/scripts/run_one.R" \
  original "${ROOT}/data/pbmc3k_prepared_cellchat.rds" \
  "${RESULTS}/original.tsv"

/usr/bin/time -v -o "${RESULTS}/sparse_stream.time.txt" \
  "${R_SCRIPT}" "${ROOT}/scripts/run_one.R" \
  sparse_stream "${ROOT}/data/pbmc3k_prepared_cellchat.rds" \
  "${RESULTS}/sparse_stream.tsv"

"${R_SCRIPT}" "${ROOT}/scripts/compare_outputs.R" \
  "${RESULTS}/original.computed.rds" \
  "${RESULTS}/sparse_stream.computed.rds" \
  "${RESULTS}/output_comparison.tsv"

"${R_SCRIPT}" "${ROOT}/scripts/summarize_run.R" \
  "${RESULTS}/original.tsv" "${RESULTS}/sparse_stream.tsv" \
  "${RESULTS}/original.time.txt" "${RESULTS}/sparse_stream.time.txt" \
  "${RESULTS}/runtime_memory_summary.tsv"

echo "VALIDATION PASSED"
echo "Results: ${RESULTS}"

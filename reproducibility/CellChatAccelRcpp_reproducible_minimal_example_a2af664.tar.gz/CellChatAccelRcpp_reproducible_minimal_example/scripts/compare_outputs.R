#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("usage: compare_outputs.R ORIGINAL_RDS ACCEL_RDS OUT_TSV")
original <- readRDS(args[[1]])
accelerated <- readRDS(args[[2]])

max_abs <- function(a, b) {
  if (!identical(dim(a), dim(b))) return(Inf)
  max(abs(as.numeric(a) - as.numeric(b)), na.rm = TRUE)
}
pearson <- function(a, b) {
  a <- as.numeric(a)
  b <- as.numeric(b)
  if (identical(a, b)) return(1)
  suppressWarnings(cor(a, b, use = "complete.obs"))
}
one <- function(metric, a, b) {
  data.frame(
    metric = metric,
    max_abs = max_abs(a, b),
    pearson = pearson(a, b),
    same_dim = identical(dim(a), dim(b)),
    stringsAsFactors = FALSE
  )
}

result <- rbind(
  one("prob", original@net$prob, accelerated@net$prob),
  one("pval", original@net$pval, accelerated@net$pval),
  one("weight", original@net$weight, accelerated@net$weight),
  one("count", original@net$count, accelerated@net$count),
  one("pathway_prob", original@netP$prob, accelerated@netP$prob)
)
write.table(result, args[[3]], sep = "\t", quote = FALSE, row.names = FALSE)
print(result)

if (!all(result$same_dim)) stop("output dimensions differ")
if (!all(abs(result$pearson - 1) < 1e-12)) stop("output correlations differ")
if (result$max_abs[result$metric == "prob"] > 1e-12) stop("probability difference exceeds tolerance")
if (result$max_abs[result$metric == "pval"] != 0) stop("p-values differ")
if (result$max_abs[result$metric == "count"] != 0) stop("aggregate counts differ")

#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
expected_ref <- if (length(args)) args[[1]] else "unknown"
suppressPackageStartupMessages(library(CellChatAccelRcpp))

expected_exports <- c(
  "computeAveExprAccelRcpp",
  "computeCommunProbAccelRcpp",
  "computeCommunProbPathwayAccelRcpp",
  "aggregateNetAccelRcpp"
)
missing <- setdiff(expected_exports, getNamespaceExports("CellChatAccelRcpp"))
if (length(missing)) stop("missing exports: ", paste(missing, collapse = ", "))
if (.Machine$sizeof.pointer < 8L) stop("a 64-bit R session is required")

cat("requested GitHub ref:", expected_ref, "\n")
cat("package version:", as.character(packageVersion("CellChatAccelRcpp")), "\n")
cat("package path:", find.package("CellChatAccelRcpp"), "\n")
cat("R pointer size:", .Machine$sizeof.pointer, "bytes\n")
cat("exports:", paste(expected_exports, collapse = ", "), "\n")

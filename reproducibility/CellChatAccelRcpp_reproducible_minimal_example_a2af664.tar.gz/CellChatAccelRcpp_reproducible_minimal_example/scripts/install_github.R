#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("usage: install_github.R GITHUB_REF LIBRARY SOURCE_TARBALL")
ref <- args[[1]]
lib <- normalizePath(args[[2]], mustWork = FALSE)
source_tarball <- args[[3]]
dir.create(lib, recursive = TRUE, showWarnings = FALSE)

if (file.exists(source_tarball)) {
  install.packages(source_tarball, repos = NULL, type = "source", lib = lib)
} else {
  if (!requireNamespace("remotes", quietly = TRUE)) {
    stop("The R package remotes is required for GitHub installation.")
  }
  remotes::install_github(
    paste0("Blake-Deng/CellChatAccelRcpp@", ref),
    lib = lib,
    dependencies = FALSE,
    upgrade = "never",
    force = TRUE,
    quiet = FALSE
  )
}

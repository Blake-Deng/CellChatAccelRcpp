#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 5L) {
  stop("usage: summarize_run.R ORIGINAL_TSV ACCEL_TSV ORIGINAL_TIME ACCEL_TIME OUT_TSV")
}

parse_time <- function(path, label) {
  lines <- readLines(path, warn = FALSE)
  hit <- grep(label, lines, fixed = TRUE, value = TRUE)
  if (!length(hit)) return(NA_real_)
  as.numeric(trimws(sub("^.*: ", "", tail(hit, 1L))))
}
parse_wall <- function(path) {
  lines <- readLines(path, warn = FALSE)
  hit <- grep("Elapsed (wall clock) time", lines, fixed = TRUE, value = TRUE)
  if (!length(hit)) return(NA_character_)
  sub("^.*\\): ", "", tail(hit, 1L))
}

original <- read.delim(args[[1]], stringsAsFactors = FALSE)
accelerated <- read.delim(args[[2]], stringsAsFactors = FALSE)
result <- rbind(
  transform(
    original,
    wall_time = parse_wall(args[[3]]),
    peak_rss_kb = parse_time(args[[3]], "Maximum resident set size (kbytes)")
  ),
  transform(
    accelerated,
    wall_time = parse_wall(args[[4]]),
    peak_rss_kb = parse_time(args[[4]], "Maximum resident set size (kbytes)")
  )
)
result$peak_rss_mib <- result$peak_rss_kb / 1024
write.table(result, args[[5]], sep = "\t", quote = FALSE, row.names = FALSE)
print(result)

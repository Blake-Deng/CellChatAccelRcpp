#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("usage: run_one.R ENGINE PREPARED_RDS OUT_TSV")
engine <- args[[1]]
prepared <- args[[2]]
out <- args[[3]]
if (!engine %in% c("original", "sparse_stream")) stop("unsupported engine: ", engine)

suppressPackageStartupMessages({
  library(CellChat)
  library(CellChatAccelRcpp)
})
if (requireNamespace("future", quietly = TRUE)) future::plan("sequential")

object <- readRDS(prepared)
object@idents <- droplevels(object@idents)
start <- proc.time()[["elapsed"]]

if (engine == "original") {
  result <- CellChat::computeCommunProb(object, nboot = 100, seed.use = 1L)
  result <- CellChat::filterCommunication(result, min.cells = 10)
  result <- CellChat::computeCommunProbPathway(result)
  result <- CellChat::aggregateNet(result)
} else {
  result <- CellChatAccelRcpp::computeCommunProbAccelRcpp(
    object, nboot = 100, seed.use = 1L, algorithm = "sparse_stream"
  )
  result <- CellChat::filterCommunication(result, min.cells = 10)
  result <- CellChatAccelRcpp::computeCommunProbPathwayAccelRcpp(result)
  result <- CellChatAccelRcpp::aggregateNetAccelRcpp(result)
}

elapsed <- proc.time()[["elapsed"]] - start
dims <- dim(object@data.signaling)
row <- data.frame(
  engine = engine,
  status = "ok",
  elapsed_sec = elapsed,
  cells = dims[[2]],
  genes = dims[[1]],
  groups = nlevels(object@idents),
  lr_pairs = nrow(object@LR$LRsig),
  nboot = 100,
  seed = 1,
  package_version = as.character(packageVersion("CellChatAccelRcpp")),
  package_path = find.package("CellChatAccelRcpp"),
  stringsAsFactors = FALSE
)
write.table(row, out, sep = "\t", quote = FALSE, row.names = FALSE)
saveRDS(result, sub("\\.tsv$", ".computed.rds", out))
print(row)

# CellChatAccelRcpp reproducible minimal example

This example verifies that a clean GitHub installation of CellChatAccelRcpp:

1. loads in a 64-bit R session;
2. runs the sparse-stream CellChat workflow;
3. reproduces the original CellChat network output; and
4. records elapsed time and peak resident memory for both workflows.

The included prepared object was derived from the public 10x Genomics PBMC3k
filtered gene-barcode matrix. It contains 1,200 cells, 997 signaling genes,
four cell groups and 1,850 ligand-receptor pairs. The raw expression download
is not required to run this example.

## Requirements

- Linux or another Unix-like system with `/usr/bin/time`
- 64-bit R 4.1 or later
- a working C++ compiler
- the R packages `CellChat`, `Rcpp`, and `remotes`
- network access when installing from GitHub

The tested R executable on this machine is:

```text
/home/dzf/miniforge3/envs/cellchat-acceleration/bin/Rscript
```

## Run

From the extracted example directory:

```bash
bash run_example.sh
```

The archive includes a source tarball built from the exact tested GitHub
commit. By default the script installs it into a private library under the
example directory, so package installation does not require network access:

```text
a2af6647db29bf6d1b59a4f42ead6e848ed9ab8e
```

Optional overrides:

```bash
R_BIN=/path/to/R R_SCRIPT=/path/to/Rscript bash run_example.sh
GITHUB_REF=main bash run_example.sh
SOURCE_TARBALL=/path/to/package.tar.gz bash run_example.sh
SKIP_INSTALL=1 R_LIBS_USER=/path/to/existing/library bash run_example.sh
```

## Expected result

The command should finish with:

```text
VALIDATION PASSED
```

The main outputs are:

- `results/output_comparison.tsv`
- `results/runtime_memory_summary.tsv`
- `results/original.computed.rds`
- `results/sparse_stream.computed.rds`

For the tested commit, all output dimensions match, all Pearson correlations
are 1, p-values and aggregate counts are identical, and the largest numerical
difference in communication probability is approximately `1.39e-17`.

## Scope

This is an installation and numerical-equivalence example, not a performance
benchmark. Runtime and memory values depend on the machine and current system
load. The fixed input, commit, bootstrap count and random seed make the
functional result reproducible.
